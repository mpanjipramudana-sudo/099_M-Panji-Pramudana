data_kelembapan = [22, 28, 34, 41, 55,  63, 72, 78, 31, 47, 66, 81, 19, 58, 69, 15, 35, 50 ,70, 90]
                  

#5 DATA TAMBAHAN#                 
#data_kelembapan= [15, 35, 50, 70, 90]

#DATA TESTING#
#data_kelembapan= [34, 35, 36, 69, 70, 71, 5, 95]



def rata_rata(data):
    total = 0 
    for nilai in data:
        total += nilai
    return total / len(data)

def status_sensor(kelembapan):
    if kelembapan < 35:
        return "KERING" 
    elif kelembapan <= 70: 
        return "NORMAL"
    else:       
        return "BASAH"

def aksi_pompa(status):
    if status == "KERING":
        return "POMPA ON"
    else:
        return "POMPA OFF"
    
def hitung_kategori(data):
    kering = 0
    normal = 0
    basah = 0
    for kelembapan in data:
        status = status_sensor (kelembapan)
        if status == "KERING":
            kering =+ 1
        elif status == "NORMAL":
            normal += 1
        else:
            basah += 1
        return kering, normal, basah

print("--- KELEMBAPAN MONITORING SYSTTEM---")

for i in range(len(data_kelembapan)):
    kelembapan = data_kelembapan[i]
    status = status_sensor(kelembapan)
    pompa = aksi_pompa(status)

    print(i+1, ".", kelembapan, "%", "->", status, "/", pompa)

kering, normal, basah = hitung_kategori(data_kelembapan)
rata = rata_rata(data_kelembapan)
average = rata_rata(data_kelembapan)

print()
print("=== RINGKASAN ===")
print("Total Data:", len (data_kelembapan))
print("KERING / POMPA ON", kering)
print("NOMRAL / POMPA OFF", normal)
print("BASAH / POMPA OFF", basah)
print("Rata_rata Kelembapan", round(average, 2), "%")
print("Minimum:", min(data_kelembapan), "%")
print("Maksimum", max(data_kelembapan), "%")
            